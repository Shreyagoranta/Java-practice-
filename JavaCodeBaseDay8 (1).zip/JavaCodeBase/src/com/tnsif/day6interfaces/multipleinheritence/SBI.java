package com.tnsif.day6interfaces.multipleinheritence;

public class SBI implements Bank{

	@Override
	public float rateofInterest() {
		// TODO Auto-generated method stub
		return 9.15f;
	}

}
