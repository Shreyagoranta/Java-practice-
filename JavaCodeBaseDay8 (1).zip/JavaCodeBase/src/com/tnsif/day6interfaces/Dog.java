package com.tnsif.day6interfaces;

public class Dog implements Pet{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
		System.out.println("Interface Method Implementation");
		
	}
	

}
