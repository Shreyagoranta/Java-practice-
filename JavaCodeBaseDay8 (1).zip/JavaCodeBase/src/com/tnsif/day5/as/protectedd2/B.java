package com.tnsif.day5.as.protectedd2;

import com.tnsif.day5.as.protectedd1.A;

public class B extends A{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1 = new B();
		b1.display(); // protected scope is outside other packages also but only through inheritence.

	}

}
