package com.tnsif.day5.as.protectedd1;

public class A {
	
	protected void display() {
		System.out.println("Display protected");
	}

}
