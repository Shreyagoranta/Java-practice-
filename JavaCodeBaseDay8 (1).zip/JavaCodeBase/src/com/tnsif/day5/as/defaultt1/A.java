package com.tnsif.day5.as.defaultt1;

public class A {
	
	
	void display() {
		System.out.println("display contents");
	}

}
