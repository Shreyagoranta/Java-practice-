package com.tnsif.day5.supermethod;

public class Animal {
	
	void eat() {
		System.out.println("eating ....");
	}

}
