package com.tnsif.day5.finall.method1;

public class B extends A{
	
	public void display(){
		
		System.out.println(" child class display");
		
	}
	
	public static void main(String[] args) {
		B b1 = new B();
		b1.display();
		
	}

}
