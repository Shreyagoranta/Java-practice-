package com.tnsif.day5.packages.package2;

public class C {
	
	public void displayC(){
		System.out.println("DisplayC method from class C");
	}

}
