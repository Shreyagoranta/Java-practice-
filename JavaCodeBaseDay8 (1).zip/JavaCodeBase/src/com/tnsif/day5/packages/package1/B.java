package com.tnsif.day5.packages.package1;

public class B {
	
	public void displayB(){
		System.out.println("DisplayB method from class B");
	}

}
