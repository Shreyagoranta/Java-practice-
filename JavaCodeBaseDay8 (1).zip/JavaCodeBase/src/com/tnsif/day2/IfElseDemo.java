//Program to demonstrate if..else statement
package com.tnsif.day2;

public class IfElseDemo {
	public static void main(String[] args) {
		int age=11;
		
		if(age>=18)
			System.out.println(" You are eligible for Voting");	
		else
			System.out.println("Sorry! You need to wait more");

		System.out.println("if else demonstration");
		
	}

}